SELECT Student.D, Student.B, Student.A FROM Student;
