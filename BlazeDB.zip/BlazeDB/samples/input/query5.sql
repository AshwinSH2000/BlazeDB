SELECT * FROM Student, Enrolled WHERE Student.A = Enrolled.A;
