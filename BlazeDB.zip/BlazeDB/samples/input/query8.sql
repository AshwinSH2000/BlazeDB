SELECT * FROM Student ORDER BY Student.B;
