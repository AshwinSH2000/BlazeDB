SELECT * FROM Student WHERE Student.A < 3;
