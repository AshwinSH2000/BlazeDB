package ed.inf.adbs.blazedb;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit tests for BlazeDB.
 */
public class BlazeDBTest {
	
	/**z
	 * Rigorous Test :-)
	 */
	@Test
	public void shouldAnswerWithTrue() {
		assertTrue(true);
	}
}
