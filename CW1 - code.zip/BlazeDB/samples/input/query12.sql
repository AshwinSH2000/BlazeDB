SELECT SUM(1), SUM(Student.A) FROM Student, Enrolled;
