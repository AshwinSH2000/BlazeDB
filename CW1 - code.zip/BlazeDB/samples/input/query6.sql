SELECT * FROM Student, Course WHERE Student.C < Course.E;
