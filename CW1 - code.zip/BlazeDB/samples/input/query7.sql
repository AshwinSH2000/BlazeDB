SELECT DISTINCT Enrolled.A FROM Enrolled;
