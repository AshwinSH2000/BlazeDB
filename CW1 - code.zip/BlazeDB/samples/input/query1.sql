SELECT * FROM Student;
