SELECT Student.A FROM Student;
